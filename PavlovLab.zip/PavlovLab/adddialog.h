#ifndef ADDDIALOG_H
#define ADDDIALOG_H

#include <QDialog>
#include "Team.h"
#include "VolleyPlayer.h"
#include <QDoubleValidator>
#include <QValidator>
#include <QIntValidator>
#include <QMessageBox>

namespace Ui {
class addDialog;
}

class addDialog : public QDialog
{
    Q_OBJECT

public:
    explicit addDialog(QWidget *parent, std::shared_ptr<Team> team, bool isAdd = true, int index = 0);
    ~addDialog();
    std::shared_ptr<Team> team;
    template <typename T>
    bool get_correct(T max, T min, T x) {
        if (x < min || x > max){
            return false;}
        return true;
    }

private slots:
    void on_pushButton_clicked();

    void on_radioButton_2_clicked();

    void on_radioButton_clicked();

private:
    bool isAdd = true;
    int index = 0;
    Ui::addDialog *ui;
};

#endif // ADDDIALOG_H
