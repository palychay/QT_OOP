#ifndef EDITMAIN_H
#define EDITMAIN_H

#include <QDialog>
#include "Team.h"

namespace Ui {
class EditMain;
}

class EditMain : public QDialog
{
    Q_OBJECT

public:
    explicit EditMain(QWidget *parent, std::shared_ptr<Team> team);
    std::shared_ptr<Team> team;
    ~EditMain();

private slots:
    void on_listWidget_currentRowChanged(int currentRow);

    void on_addButton_clicked();

    void on_editButton_clicked();

    void on_deleteButton_clicked();

private:
    Ui::EditMain *ui;
};

#endif // EDITMAIN_H
