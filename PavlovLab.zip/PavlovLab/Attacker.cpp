#include "Attacker.h"

void Attacker::draw(QPainter &painter, int startX, int startY, const QVector<int> &columnWidths, int cellHeight, int& rowIndex) const{
    QStringList rowData;
    rowData << QString::fromLocal8Bit(name)
            << QString::number(height)
            << QString::number(weight)
            << QString::number(age)
            << QString::number(power)
            << QString::number(jump);
    int x = startX;
    for (int i = 0; i < 6; ++i) {

        QRect cellRect(x, startY + rowIndex * cellHeight, columnWidths[i], cellHeight);
        painter.drawRect(cellRect);
        painter.drawText(cellRect, Qt::AlignCenter, rowData[i]);
        x += columnWidths[i];
    }
    rowIndex++;
}
