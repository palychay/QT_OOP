#include "adddialog.h"
#include "ui_adddialog.h"
#include "VolleyPlayer.h"
#include "Attacker.h"
#include <string>

addDialog::addDialog(QWidget *parent, std::shared_ptr<Team> team, bool isAdd, int index)
    : QDialog(parent)
    , team(team)
    , isAdd(isAdd)
    , index(index)
    , ui(new Ui::addDialog)
{
    ui->setupUi(this);

    if(!isAdd){
        auto player = team->team[index];

        ui->lineEdit_7->setText(QString::fromLocal8Bit(player->getName()));
        ui->lineEdit_8->setText(QString::number(player->getHeight()));
        ui->lineEdit_9->setText(QString::number(player->getWeight()));
        ui->lineEdit_10->setText(QString::number(player->getAge()));

        auto a = std::dynamic_pointer_cast<Attacker>(player);
        if (!a) {
            return;
        }

        ui->lineEdit_11->setText(QString::number(a->getPower()));
        ui->lineEdit_12->setText(QString::number(a->getJump()));
    }

}

addDialog::~addDialog()
{
    delete ui;
}

void addDialog::on_pushButton_clicked()
{
    if(isAdd){
        if(ui->radioButton->isChecked()) {
            std::string name = ui->lineEdit_7->text().toLocal8Bit().constData();
            int height = ui->lineEdit_8->text().toInt();
            double weight = ui->lineEdit_9->text().toDouble();
            int age = ui->lineEdit_10->text().toInt();
            if (get_correct(220,170,height) && get_correct(110.0, 60.0, weight) && get_correct(50,15, age)){
                std::shared_ptr<VolleyPlayer> playerV = std::make_shared<VolleyPlayer>(VolleyPlayer());
                playerV->setName(name);
                playerV->setHeight(height);
                playerV->setWeight(weight);
                playerV->setAge(age);
                team->team.push_back(playerV);
            }
            else{
                ui->lineEdit_7->clear();
                ui->lineEdit_8->clear();
                ui->lineEdit_9->clear();
                ui->lineEdit_10->clear();
                QMessageBox::warning(nullptr, "Ошибка", "Введите число в допустимом диапазоне!");
            }
        }
        else {
            std::string name = ui->lineEdit_7->text().toLocal8Bit().constData();
            int height = ui->lineEdit_8->text().toInt();
            double weight = ui->lineEdit_9->text().toDouble();
            int age = ui->lineEdit_10->text().toInt();
            int power = ui->lineEdit_11->text().toInt();
            double jump = ui->lineEdit_12->text().toDouble();
            if (get_correct(220,170,height) && get_correct(110.0, 60.0, weight) && get_correct(50,15, age)
                && get_correct(150,20,power) && get_correct(150.0, 30.0, jump)){
                std::shared_ptr<Attacker> playerV = std::make_shared<Attacker>(Attacker());
                playerV->setName(name);
                playerV->setHeight(height);
                playerV->setWeight(weight);
                playerV->setAge(age);
                playerV->setPower(power);
                playerV->setJump(jump);
                team->team.push_back(playerV);
            }
            else{
                ui->lineEdit_7->clear();
                ui->lineEdit_8->clear();
                ui->lineEdit_9->clear();
                ui->lineEdit_10->clear();
                ui->lineEdit_11->clear();
                ui->lineEdit_12->clear();
                QMessageBox::warning(nullptr, "Ошибка", "Введите число в допустимом диапазоне!");
            }
        }
    }

    else{
        if(ui->radioButton->isChecked()) {
            std::string name = ui->lineEdit_7->text().toLocal8Bit().constData();
            int height = ui->lineEdit_8->text().toInt();
            double weight = ui->lineEdit_9->text().toDouble();
            int age = ui->lineEdit_10->text().toInt();
            if (get_correct(220,170,height) && get_correct(110.0, 60.0, weight) && get_correct(50,15, age)){
                std::shared_ptr<VolleyPlayer> playerV = std::make_shared<VolleyPlayer>(VolleyPlayer());
                playerV->setName(name);
                playerV->setHeight(height);
                playerV->setWeight(weight);
                playerV->setAge(age);
                team->team[index] = playerV;
            }
            else{
                ui->lineEdit_7->clear();
                ui->lineEdit_8->clear();
                ui->lineEdit_9->clear();
                ui->lineEdit_10->clear();
                QMessageBox::warning(nullptr, "Ошибка", "Введите число в допустимом диапазоне!");
            }
        }

        else {
            std::string name = ui->lineEdit_7->text().toLocal8Bit().constData();
            int height = ui->lineEdit_8->text().toInt();
            double weight = ui->lineEdit_9->text().toDouble();
            int age = ui->lineEdit_10->text().toInt();
            int power = ui->lineEdit_11->text().toInt();
            double jump = ui->lineEdit_12->text().toDouble();
            if (get_correct(220,170,height) && get_correct(110.0, 60.0, weight) && get_correct(50,15, age)
                && get_correct(150,20,power) && get_correct(150.0, 30.0, jump)){
                std::shared_ptr<Attacker> playerV = std::make_shared<Attacker>(Attacker());
                playerV->setName(name);
                playerV->setHeight(height);
                playerV->setWeight(weight);
                playerV->setAge(age);
                playerV->setPower(power);
                playerV->setJump(jump);
                team->team[index] = playerV;
            }
            else{
                ui->lineEdit_7->clear();
                ui->lineEdit_8->clear();
                ui->lineEdit_9->clear();
                ui->lineEdit_10->clear();
                ui->lineEdit_11->clear();
                ui->lineEdit_12->clear();
                QMessageBox::warning(nullptr, "Ошибка", "Введите число в допустимом диапазоне!");
            }
        }
    }

    done(QDialog::Accepted);
}


void addDialog::on_radioButton_2_clicked()
{
    ui->lineEdit_5->show();
    ui->lineEdit_6->show();
    ui->lineEdit_11->show();
    ui->lineEdit_12->show();
}


void addDialog::on_radioButton_clicked()
{
    ui->lineEdit_5->hide();
    ui->lineEdit_6->hide();
    ui->lineEdit_11->hide();
    ui->lineEdit_12->hide();
}

