#pragma once

#include <string>
#include <boost/serialization/string.hpp>
#include <boost/serialization/access.hpp>
#include <QPainter>

using namespace std;

class VolleyPlayer
{
protected:
    string name;
    int height;
    double weight;
    int age;

public:
    VolleyPlayer();

    VolleyPlayer(const string& name, int height, double weight, int age);

    string getName(){
        return name;
    }
    int getHeight(){return height;}
    double getWeight(){return weight;}
    int getAge(){return age;}

    virtual void draw(QPainter &painter, int startX, int startY, const QVector<int> &columnWidths, int cellHeight, int& rowIndex) const;

    void setName(string name){
        this->name = name;
    }
    void setHeight(int height){this->height = height;}
    void setWeight(double weight){this->weight = weight;}
    void setAge(int age){this->age = age;}

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive& ar, const unsigned int version)
    {
        ar& name;
        ar& height;
        ar& weight;
        ar& age;
    }

    virtual ~VolleyPlayer() = default;
};

