#include "editmain.h"
#include "ui_editmain.h"
#include "adddialog.h"

EditMain::EditMain(QWidget *parent, std::shared_ptr<Team> team)
    : QDialog(parent)
    , team(team)
    , ui(new Ui::EditMain)
{
    ui->setupUi(this);
    std::for_each(team->team.begin(), team->team.end(),
                  [&](std::shared_ptr<VolleyPlayer> p) {
                      ui->listWidget->addItem(QString::fromLocal8Bit(p->getName()));
                  });
    ui->listWidget->setCurrentRow(0);
}

EditMain::~EditMain()
{
    delete ui;
}

void EditMain::on_listWidget_currentRowChanged(int currentRow)
{
    if(currentRow < 0 || currentRow >= team->team.size()) {
        return;
    }

    auto player = team->team[currentRow];

    ui->lineEdit_1->setText(QString::fromLocal8Bit(player->getName()));
    ui->lineEdit_2->setText(QString::number(player->getHeight()));
    ui->lineEdit_3->setText(QString::number(player->getWeight()));
    ui->lineEdit_4->setText(QString::number(player->getAge()));

    auto a = std::dynamic_pointer_cast<Attacker>(player);
    if (!a) {
        ui->lineEdit_5->hide();
        ui->lineEdit_6->hide();
        ui->power->hide();
        ui->jump->hide();
        return;
    }
    ui->lineEdit_5->show();
    ui->lineEdit_6->show();
    ui->power->show();
    ui->jump->show();

    ui->lineEdit_5->setText(QString::number(a->getPower()));
    ui->lineEdit_6->setText(QString::number(a->getJump()));
}



void EditMain::on_addButton_clicked()
{
    int sz = team->team.size();
    addDialog dlg(this, team);
    if(dlg.exec() == QDialog::Accepted){
        if (dlg.team->team.size() != 0 && dlg.team->team.size() != sz){
            team = dlg.team;
            ui->listWidget->addItem(QString::fromLocal8Bit(team->team[team->team.size() - 1]->getName()));
            ui->listWidget->setCurrentRow(team->team.size() - 1);
        }
        return;
    }
}


void EditMain::on_editButton_clicked()
{
    if (team->team.size() == 0){
        return;
    }
    int indx = ui->listWidget->currentRow();
    addDialog dlg(this, team, false, indx);
    if(dlg.exec() == QDialog::Accepted){
        on_listWidget_currentRowChanged(indx);
        team = dlg.team;
        ui->listWidget->setCurrentRow(indx);
    }
}


void EditMain::on_deleteButton_clicked()
{
    int sz = team->team.size();
    if (sz == 0){
        return;
    }
    int indx = ui->listWidget->currentRow();
    auto selected = team->team.begin() + indx;
    team->team.erase(selected);

    ui->lineEdit_1->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();

    if (indx == (sz-1)){
        ui->listWidget->takeItem(indx);
        on_listWidget_currentRowChanged(indx-1);
        ui->listWidget->setCurrentRow(indx-1);
        return;
    }
    ui->listWidget->takeItem(indx);
    on_listWidget_currentRowChanged(indx);
    ui->listWidget->setCurrentRow(indx);
}

