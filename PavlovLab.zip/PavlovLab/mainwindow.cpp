#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include "editmain.h"
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <sstream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    filename = "";
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionOpen_triggered()
{
    filename = QFileDialog::getOpenFileName(this, tr("Открыть"), QDir::currentPath(), tr("Текстовый документ (*.txt)"));
    if (!filename.isEmpty())
        ui->pavWidget->load(filename);
}

void MainWindow::on_actionSave_as_triggered()
{

    filename = QFileDialog::getSaveFileName(this, tr("Сохранить как"), QDir::currentPath(), tr("Текстовый документ (*.txt)"));
    if (!filename.isEmpty())
        ui->pavWidget->save(filename);
}


void MainWindow::on_actionClear_triggered()
{
    ui->pavWidget->clear();
}


void MainWindow::on_actionExit_triggered()
{
    close();
}

template<class T>
void clone(T& src, T& trg)
{
    std::stringstream stream;
    boost::archive::text_oarchive out(stream);
    out << src;
    boost::archive::text_iarchive in(stream);
    in >> trg;
}

void MainWindow::on_action_triggered()
{
    std::shared_ptr<Team> temp = std::make_shared<Team>(ui->pavWidget->team);
    EditMain dlg(this, temp);

    int res = dlg.exec();
    if (res == QDialog::Accepted) {
        ui->pavWidget->team = *dlg.team;
        ui->pavWidget->update();
    }
}

