#include "VolleyPlayer.h"

VolleyPlayer::VolleyPlayer() : name(""), height(0), weight(0), age(0) {}

VolleyPlayer::VolleyPlayer(const string& name, int height, double weight, int age):
	name(name), height(height), weight(weight), age(age) {}

void VolleyPlayer::draw(QPainter &painter, int startX, int startY, const QVector<int> &columnWidths, int cellHeight, int &rowIndex) const {
    QStringList rowData;
    rowData << QString::fromLocal8Bit(name)
            << QString::number(height)
            << QString::number(weight)
            << QString::number(age);

    int x = startX;  // Текущая X-координата
    for (int i = 0; i < columnWidths.size(); ++i) {
        QRect cellRect(x, startY + rowIndex * cellHeight, columnWidths[i], cellHeight);
        painter.drawRect(cellRect);
        if (i < rowData.size()) {
            painter.drawText(cellRect, Qt::AlignCenter, rowData[i]);
        }
        x += columnWidths[i];  // Смещаем X-координату на ширину текущего столбца
    }
    rowIndex++;
}
