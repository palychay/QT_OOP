#include "Team.h"
#include <fstream>
#include <boost/archive/text_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/export.hpp>
#include <algorithm>
#include <functional>
#include <iostream>
#include <string>

BOOST_CLASS_EXPORT(Attacker)
BOOST_CLASS_EXPORT(VolleyPlayer)


void Team::readFromFile(const string& filename) {
    ifstream inFile(filename);
    boost::archive::text_iarchive ia(inFile);
    ia >> team;
}

void Team::writeToFile(const string& filename) const {
    ofstream outFile(filename);
    boost::archive::text_oarchive oa(outFile);
    oa << team;
}

int Team::calculateColumnWidth() const
{
    QFont font;
    QFontMetrics fontMetrics(font);  // Получаем метрики текущего шрифта
    int maxWidth = 150;

    for (auto &text : team) {
        int textWidth = fontMetrics.horizontalAdvance(QString::fromStdString(text->getName()));  // Ширина текста
        if (textWidth > maxWidth) {
            maxWidth = textWidth;
        }
    }
    return maxWidth+10;
}

bool Team::IsEmpty() const {
    return team.empty();
}

void Team::clearPlayers() {
    team.clear();
}

QSize Team::calculTableSize() const{
    int widthTable = 6 * 150 + calculateColumnWidth();
    int heightTable = (team.size() + 1) * 30 + 2 * 20;
    return QSize(widthTable, heightTable);
}

void Team::drawCell(QPainter &painter, int x, int y, int width, int height, const QString &text) {
    QRect cellRect(x, y, width, height);
    painter.drawRect(cellRect);
    painter.drawText(cellRect, Qt::AlignCenter, text);
}

void Team::draw(QPainter &painter) {
    int startX = 30;       // Начальная позиция по оси X
    int startY = 20;       // Начальная позиция по оси Y
    int cellWidth = 160;   // Ширина ячейки
    int cellHeight = 30;   // Высота ячейки
    int Widthtb = calculateColumnWidth();
    // Заголовки столбцов
    QStringList headers = {"Name", "Height", "Weight", "Age", "Power", "Jump"};

    // Отрисовка заголовков с использованием for_each и bind
    QVector<int> columnWidths(headers.size());
    for (int i = 0; i < headers.size(); ++i) {
        if (i == 0) {
            columnWidths[i] = calculateColumnWidth();
        } else {
            columnWidths[i] = 160;  // Фиксированная ширина для остальных
        }
    }

    // Отрисовка заголовков
    int headerY = startY;
    int x = startX;  // Текущая X-координата
    for (int colIndex = 0; colIndex < headers.size(); ++colIndex) {
        drawCell(painter, x, headerY, columnWidths[colIndex], cellHeight, headers[colIndex]);
        x += columnWidths[colIndex];  // Смещаем X-координату на ширину текущего столбца
    }

    // Рисуем строки данных с использованием for_each и bind
    int rowIndex = 1; // Начинаем с 1, так как первая строка — это заголовки

    // Используем for_each для перебора элементов класса Team
    std::for_each(team.begin(), team.end(),
                  [&painter, startX, startY, &columnWidths, cellHeight, &rowIndex](auto& player) {
                      player->draw(painter, startX, startY, columnWidths, cellHeight, rowIndex);
                  });
}

Team::~Team() {
    clearPlayers();
}
